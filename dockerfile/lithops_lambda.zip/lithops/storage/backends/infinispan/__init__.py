from lithops.storage.backends.infinispan.infinispan import InfinispanBackend as StorageBackend
